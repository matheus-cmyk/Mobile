package com.example.appfuelsaver;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText edtmodelo, edtplaca, edtdistancia, edtconsumo, edtpreco;
    Button btncalcular;
    TextView txtR1, txtR2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
edtdistancia = findViewById(R.id.edtdistancia);
edtmodelo =findViewById(R.id.edtmodelo);
edtconsumo = findViewById(R.id.edtconsumo);
edtplaca = findViewById(R.id.edtplaca);
edtpreco = findViewById(R.id.edtpreco);
btncalcular = findViewById(R.id.btncalcular);
txtR1 = findViewById(R.id.txtR1);
txtR2 = findViewById(R.id.txtR2);

btncalcular.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        double valorA, valorB, valorC, result1, result2;
        try {
            valorA = Double.parseDouble(edtdistancia.getText().toString());
            valorB = Double.parseDouble(edtconsumo.getText().toString());
            valorC = Double.parseDouble(edtpreco.getText().toString());
            //Cálculo do consumo de combústivel//
            result1 = valorA / valorB;
            //cálculo do preço da viagem//
            result2 = result1 * valorC;
            //Resultados//
            txtR1.setText("O combustível necessário é " + result1+"L");
            txtR2.setText("O preço total da viagem é " + result2+"R$");
        } catch (NumberFormatException e){
            Toast.makeText(view.getContext(), "por favor, preencha ambos os campos corretamente",Toast.LENGTH_SHORT).show();
        }
    }
});
    }
}